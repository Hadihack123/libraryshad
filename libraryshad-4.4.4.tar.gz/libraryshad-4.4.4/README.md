How to import libraryshad library is as follows:

<< from libraryshad.shad import robo_shad >>

An example:

from libraryshad.shad import robo_shad 

bot = robo_shad("Your Auth Account")


Made by mamadcoder

Address of our team's GitHub :

https://github.com/Arseinlibrary/Arsein__library.gitin__library.git
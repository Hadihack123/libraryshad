#Copyright (C) 2022 shadroid

version= "4.4.4"
copyright = " shadroid Copyright (C) 2022 mamadcoder \n\n"
mamad = "mamadcoder"

class chop:
	print(f"shadroid library version {version}\n{copyright}\n \n\nدر حال فعال شدن کمی صبور باشید...\n")
	print(" ")
	print(". . . . . . . . . . . ")

